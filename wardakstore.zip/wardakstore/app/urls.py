from django.urls import path
from app import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.home,name='home'),
    path('product-detail/<int:pk>', views.product_detail, name='product-detail'),
    path('add-to-cart/', views.add_to_cart, name='add-to-cart'),
    path('show-cart/', views.show_cart, name='show-cart'),
    path('pluscart/', views.plus_cart),
    path('minuscart/', views.minus_cart),
    path('removecart/', views.remove_cart),
    path('buy/', views.buy_now, name='buy-now'),
    path('profile/', views.profile, name='profile'),
    path('address/', views.address, name='address'),
    path('orders/', views.orders, name='orders'),
    path('changepassword/', views.change_password, name='changepassword'),
    path('shawls/', views.shawls, name='shawls'),
    path('shawls/<slug:data>', views.shawls, name='shawlsdata'),
    path('handbag/', views.handbag, name='handbag'),
    path('handbag/<slug:data>', views.handbag, name='handbagdata'),
    path('pakol/', views.pakol, name='pakol'),
    path('pakol/<slug:data>', views.pakol, name='pakoldata'),
    path('jacket/', views.jacket, name='jacket'),
    path('jacket/<slug:data>', views.jacket, name='jacketdata'),

    path('ring/', views.ring, name='ring'),
    path('ring/<slug:data>', views.ring, name='ringdata'),
    path('silajeet/', views.silajeet, name='silajeet'),
    path('silajeet/<slug:data>', views.silajeet, name='silajeetdata'),
    path('dryfruit/', views.dryfruit, name='dryfruit'),
    path('dryfruit/<slug:data>', views.dryfruit, name='dryfruitdata'),




    path('login/', views.userlogin, name='login'),
    path('logout/', views.userlogout, name='logout'),
    path('registration/', views.customerregistration, name='customerregistration'),
    path('checkout/', views.checkout, name='checkout'),
    path('paymentdone/', views.payment_done, name='paymentdone'),
    path("password_reset", views.password_reset_request, name="password_reset"),
    path('contactus/', views.contactus, name='contact'),
    path('search', views.search, name="search"),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
