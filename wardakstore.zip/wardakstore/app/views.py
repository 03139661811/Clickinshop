from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash
from .models import Customer,Product,Cart,OrderPlaced
from .forms import CustomerRegistrationForm,UserLoginForm,userpasswordchangeform,userprofile,ContactU
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse
from django.contrib.auth.forms import PasswordResetForm
from django.utils.http import urlsafe_base64_encode
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_bytes
from django.template.loader import render_to_string



def home(request):
    cart_total_item = 0
    handbag = Product.objects.filter(category='HB')
    shawls = Product.objects.filter(category='S')
    jackets = Product.objects.filter(category='J')
    pakols = Product.objects.filter(category='P')
    rings = Product.objects.filter(category='R')
    silajeet = Product.objects.filter(category='ST')
    dryfruit = Product.objects.filter(category='DF')
    if request.user.is_authenticated:
        cart_total_item= len(Cart.objects.filter(user=request.user))
    return render(request, 'app/home.html',{'handbag':handbag,'shawls':shawls,'jackets':jackets,
    'pakols':pakols,'rings':rings,'silajeet':silajeet,'dryfruit':dryfruit,'cart_total_item':cart_total_item})

def product_detail(request,pk):
        cart_total_item = 0
        product = Product.objects.get(pk=pk)
        item_already_in_cart = False
        if request.user.is_authenticated:
            cart_total_item= len(Cart.objects.filter(user=request.user))
            item_already_in_cart = Cart.objects.filter(Q(product=product.id) & Q(user=request.user)).exists
        return render(request, 'app/productdetail.html',{'product':product,'item_already_in_cart':item_already_in_cart,
        'cart_total_item':cart_total_item})

def add_to_cart(request):
    if request.user.is_authenticated:
        user = request.user
        product_id = request.GET.get('prod_id')
        product_inst = Product.objects.get(id=product_id)
        saveitemcart=Cart(user=user,product=product_inst)
        saveitemcart.save()
        return redirect('/show-cart/')
    else:
        messages.warning(request,"To Continue Shopping Log In First...!!")
        return redirect('/login/')

def show_cart(request):
    cart_total_item = 0
    if request.user.is_authenticated:
        cart_total_item= len(Cart.objects.filter(user=request.user))
        user = request.user
        cartitems = Cart.objects.filter(user=user)
        amount=0.0
        shipping_amout=70
        total_amount = 0.0
        cart_product  = [p for p in Cart.objects.all() if p.user == user]
        if cart_product:
            for p in cart_product:
                temp_amount = (p.quantity * p.product.discounted_price)
                amount+=temp_amount
                total_amount=amount+shipping_amout
            return render(request,'app/addtocart.html',{'cartitems':cartitems,'total_amount':total_amount,
            'amount':amount,'cart_total_item':cart_total_item})
        else:
            return render(request,'app/emptycart.html')


def plus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.quantity+=1
        c.save()
        amount=0.0
        shipping_amout=70
        total_amount = 0.0
        cart_product  = [p for p in Cart.objects.all() if p.user == request.user]
        if cart_product:
            for p in cart_product:
                temp_amount = (p.quantity * p.product.discounted_price)
                amount+=temp_amount
            
            data = {
                'quantity':c.quantity,
                'amount':amount,
                'total_amount':amount+shipping_amout
            }
            return JsonResponse(data)



def minus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.quantity-=1
        c.save()
        amount=0.0
        shipping_amout=70
        total_amount = 0.0
        cart_product  = [p for p in Cart.objects.all() if p.user == request.user]
        if cart_product:
            for p in cart_product:
                temp_amount = (p.quantity * p.product.discounted_price)
                amount+=temp_amount
                
            data = {
                'quantity':c.quantity,
                'amount':amount,
                'total_amount':amount+shipping_amout
            }
            return JsonResponse(data)


def remove_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.delete()
        amount=0.0
        shipping_amout=70
        total_amount = 0.0
        cart_product  = [p for p in Cart.objects.all() if p.user == request.user]
        if cart_product:
            for p in cart_product:
                temp_amount = (p.quantity * p.product.discounted_price)
                amount+=temp_amount    
        data = {
            'amount':amount,
            'total_amount':amount+shipping_amout
        }
        return JsonResponse(data)


def buy_now(request):
 return render(request, 'app/buynow.html')

def profile(request):
    cart_total_item = 0
    if request.user.is_authenticated:
        cart_total_item= len(Cart.objects.filter(user=request.user))
    if request.method == 'POST':
        form = userprofile(request.POST)
        if form.is_valid():
            usr=request.user
            name=form.cleaned_data['name']
            locality=form.cleaned_data['locality']
            city=form.cleaned_data['city']
            state=form.cleaned_data['state']
            zipcode=form.cleaned_data['zipcode']
            reg =Customer(user=usr,name=name,locality=locality,city=city,state=state,zipcode=zipcode)
            reg.save()
    else:
        form = userprofile()
    return render(request, 'app/profile.html',{'form':form,'active':'btn-primary','cart_total_item':cart_total_item})

def address(request):
    cart_total_item=0
    if request.user.is_authenticated:
        cart_total_item=len(Cart.objects.filter(user=request.user))
    customerdata = Customer.objects.filter(user=request.user)
    return render(request, 'app/address.html',{'active':'btn-primary','customerdata':customerdata,'cart_total_item':cart_total_item})

def orders(request):
    cart_total_item=0
    if request.user.is_authenticated:
        cart_total_item=len(Cart.objects.filter(user=request.user))
    op = OrderPlaced.objects.filter(user=request.user)
    return render(request, 'app/orders.html',{'op':op,'cart_total_item':cart_total_item})

def change_password(request):
    cart_total_item=0
    if request.user.is_authenticated:
        cart_total_item=len(Cart.objects.filter(user=request.user))
    if request.method == 'POST':
        form = userpasswordchangeform(request.user, request.POST)
        if form.is_valid():
            user=form.save()
            update_session_auth_hash(request,user)
            return redirect('/profile/')
    else:
        form = userpasswordchangeform(request.user)
    return render(request, 'app/changepassword.html',{'form':form,'cart_total_item':cart_total_item})

def shawls(request,data=None):
    cart_total_item=0
    if request.user.is_authenticated:
        cart_total_item=len(Cart.objects.filter(user=request.user))
    if data == None:
        shawls = Product.objects.filter(category='S')
    elif data == 'Below':
        shawls = Product.objects.filter(category='S').filter(discounted_price__lt=10000)
    elif data == 'Above':
        shawls = Product.objects.filter(category='S').filter(discounted_price__gt=10000)
    return render(request, 'app/mobile.html',{'shawls':shawls,'cart_total_item':cart_total_item})


def handbag(request,data=None):
    cart_total_item = 0
    if request.user.is_authenticated:
        cart_total_item = len(Cart.objects.filter(user=request.user))
    if data == None:
        handbag = Product.objects.filter(category='HB')
    elif data == 'Below':
        handbag = Product.objects.filter(category='HB').filter(discounted_price__lt=10000)
    elif data == 'Above':
        handbag = Product.objects.filter(category='HB').filter(discounted_price__gt=10000)
    return render(request,'app/laptop.html',{'handbag':handbag,'cart_total_item':cart_total_item})


def pakol(request,data=None):
    cart_total_item = 0
    if request.user.is_authenticated:
        cart_total_item = len(Cart.objects.filter(user=request.user))
    if data == None:
        pakol = Product.objects.filter(category='P')
    elif data == 'Below':
        pakol = Product.objects.filter(category='P').filter(discounted_price__lt=10000)
    elif data == 'Above':
        pakol = Product.objects.filter(category='P').filter(discounted_price__gt=10000)
    return render(request,'app/topwear.html',{'pakol':pakol,'cart_total_item':cart_total_item})

def jacket(request,data=None):
    cart_total_item = 0
    if request.user.is_authenticated:
        cart_total_item = len(Cart.objects.filter(user=request.user))
    if data == None:
        jackets = Product.objects.filter(category='J')
    elif data == 'Below':
        jackets = Product.objects.filter(category='J').filter(discounted_price__lt=10000)
    elif data == 'Above':
        jackets = Product.objects.filter(category='J').filter(discounted_price__gt=10000)
    return render(request,'app/bottomwear.html',{'jackets':jackets,'cart_total_item':cart_total_item})


def ring(request,data=None):
    cart_total_item = 0
    if request.user.is_authenticated:
        cart_total_item = len(Cart.objects.filter(user=request.user))
    if data == None:
        ring = Product.objects.filter(category='R')
    elif data == 'Below':
        ring = Product.objects.filter(category='R').filter(discounted_price__lt=10000)
    elif data == 'Above':
        ring = Product.objects.filter(category='R').filter(discounted_price__gt=10000)
    return render(request,'app/rings.html',{'ring':ring,'cart_total_item':cart_total_item})

def silajeet(request,data=None):
    cart_total_item = 0
    if request.user.is_authenticated:
        cart_total_item = len(Cart.objects.filter(user=request.user))
    if data == None:
        silajeet = Product.objects.filter(category='ST')
    elif data == 'Below':
        silajeet = Product.objects.filter(category='ST').filter(discounted_price__lt=10000)
    elif data == 'Above':
        silajeet = Product.objects.filter(category='ST').filter(discounted_price__gt=10000)
    return render(request,'app/silajeet.html',{'silajeet':silajeet,'cart_total_item':cart_total_item})

def dryfruit(request,data=None):
    cart_total_item = 0
    if request.user.is_authenticated:
        cart_total_item = len(Cart.objects.filter(user=request.user))
    if data == None:
        dryfruit = Product.objects.filter(category='DF')
    elif data == 'Below':
        dryfruit = Product.objects.filter(category='DF').filter(discounted_price__lt=10000)
    elif data == 'Above':
        dryfruit = Product.objects.filter(category='DF').filter(discounted_price__gt=10000)
    return render(request,'app/dryfruit.html',{'dryfruit':dryfruit,'cart_total_item':cart_total_item})


def userlogin(request):
    if request.method == 'POST':
        form = UserLoginForm(request,data=request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            usr = authenticate(username=username,password=password)
            if usr is not None:
                login(request,usr)
                return redirect('/profile/')
    else:
        form = UserLoginForm()
    return render(request, 'app/login.html',{'form':form})

def customerregistration(request):
    if request.method == 'POST':
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request,'Congratulation..! Registered Successfully ' )
            form.save()
    else:
        form = CustomerRegistrationForm()
    return render(request, 'app/customerregistration.html',{'form':form})

def checkout(request):
    if request.user.is_authenticated:
        custaddr = Customer.objects.filter(user=request.user)
        custprod = Cart.objects.filter(user=request.user)
        amount=0.0
        shipping_amout=70
        total_amount = 0.0
        cart_product  = [p for p in Cart.objects.all() if p.user == request.user]
        if cart_product:
            for p in cart_product:
                temp_amount = (p.quantity * p.product.discounted_price)
                amount+=temp_amount
            total_amount = amount+shipping_amout
        return render(request, 'app/checkout.html',{'custaddr':custaddr,'custprod':custprod,'total_amount':total_amount})
    else:
        messages.warning(request,"To Continue Shopping Log In First...!!")
        return redirect('/login/')
        

def payment_done(request):
    if request.method == 'GET':
        user = request.user
        cust_id = request.GET.get('custid')
        customer = Customer.objects.get(id=cust_id)
        cart = Cart.objects.filter(user=user)
        for c in cart:
            OrderPlaced(user=user,customer=customer,product=c.product,quantity=c.quantity).save()
            c.delete()
        return redirect('/orders/')


def password_reset_request(request):
	if request.method == "POST":
		password_reset_form = PasswordResetForm(request.POST)
		if password_reset_form.is_valid():
			data = password_reset_form.cleaned_data['email']
			associated_users = User.objects.filter(Q(email=data))
			if associated_users.exists():
				for user in associated_users:
					subject = "Password Reset Requested"
					email_template_name = "app/password_reset_email.txt"
					c = {
					"email":user.email,
					'domain':'127.0.0.1:8000',
					'site_name': 'Website',
					"uid": urlsafe_base64_encode(force_bytes(user.pk)),
					"user": user,
					'token': default_token_generator.make_token(user),
					'protocol': 'http',
					}
					email = render_to_string(email_template_name, c)
					try:
						send_mail(subject, email, 'admin@example.com' , [user.email], fail_silently=False)
					except BadHeaderError:
						return HttpResponse('Invalid header found.')
					return redirect ("/password_reset/done/")
	password_reset_form = PasswordResetForm()
	return render(request=request, template_name="app/password_reset.html", context={"password_reset_form":password_reset_form})


def contactus(request):
    if request.method == 'POST':
        form = ContactU(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = ContactU()
        return render(request,'app/contactus.html',{'form':form})


def search(request):
    if request.method == "GET":
        searched = request.GET.get("search")
        prd = Product.objects.filter(title__icontains=searched)
        return render(request,'app/search.html',{'prd':prd})
    else:
        return render(request,'app/search.html')
    
    
def userlogout(request):
    logout(request)
    return redirect('/login/')